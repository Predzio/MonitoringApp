package com.adrian_kubik.monitoring

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RegisterTestCorrect {
    private val appContext = InstrumentationRegistry.getInstrumentation().targetContext
    private var vm: FbViewModel? = null

    @Before
    fun setup() {
        FirebaseApp.initializeApp(appContext)
        vm = FbViewModel(null, FirebaseAuth.getInstance())
    }

    @Test
    fun register() {
        val email = "testtest5141@gmail.com"
        val password = "wx$2H115"

        runBlocking {
            vm!!.onSignup(email, password)
            delay(2000)
        }

        Assert.assertTrue(vm!!.signedIn.value)
    }
}