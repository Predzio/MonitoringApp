package com.adrian_kubik.monitoring

class GetParamTest {
}