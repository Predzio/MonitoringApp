package com.adrian_kubik.monitoring

class AddParamTest {
}