package com.adrian_kubik.monitoring.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.annotation.OptIn
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavController
import com.adrian_kubik.monitoring.DestinationScreen
import com.adrian_kubik.monitoring.DetectAlgorithm.DifferencePixel
import com.adrian_kubik.monitoring.DetectAlgorithm.HogMotionDetector
import com.adrian_kubik.monitoring.R
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import com.adrian_kubik.monitoring.auth.views.HistoryItem
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext


@Composable
@OptIn(UnstableApi::class)
fun PlayerScreen(
    navController: NavController,
    vm: FbViewModel,
) {
    val context = LocalContext.current

    AndroidView(
        modifier = Modifier.focusable(false),
        factory = { vm.exPlayer.getSurfacePlayer() }
    )
    /*
    DisposableEffect(Unit) {
        onDispose {
            // exPlayer.releaseAll()
        }
    }*/


    val hogDetect = remember { HogMotionDetector() }
    val notificationManager = remember{ NotificationManagerCompat.from(context)}
    var diffPixel: DifferencePixel

    LaunchedEffect(Unit) {

        withContext(Dispatchers.Main) {
            delay(16000)
            println("START!")
            if(vm.isDetectionOn.value) {

                diffPixel = DifferencePixel(vm.exPlayer.getBitmap())
                while (isActive) {
                    //vm.exPlayer.getVideoFormat()

                    val b: Bitmap = vm.exPlayer.getBitmap()
                    println("${b.width} x ${b.height} x ${b.byteCount}")

                    if(vm.isDetectionLevel.value) {
                        if (diffPixel.activeDetection(b)) {
                            val imgData = vm.exPlayer.getImageDataFrom(b)
                            vm.historyList.add(HistoryItem(bitmap = b, date = Timestamp.now()))
                            async{ vm.insertImage(imgData) }.await()
                            IntruderAlert(context)
                            println("Wysłano")
                        }
                    }else {
                        if(hogDetect.detectMotion(b)){
                            val imgData = vm.exPlayer.getImageDataFrom(b)
                            vm.historyList.add(HistoryItem(bitmap = b, date = Timestamp.now()))
                            async{ vm.insertImage(imgData) }.await()
                            IntruderAlert(context)
                            println("Wysłano")
                        }
                    }

                    delay(500)  // Przyjmuje 30 klatek na sekundę
                }
            }

        }
    }

        //Zaczyna się
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = {
                        navController.navigate(DestinationScreen.History.route) {}
                }

            ) {
                Text("HISTORIA")
            }

            Button(
                onClick = {
                    navController.navigate(DestinationScreen.Settings.route) {}
                }
            ) {
                Text("USTAWIENIA")
            }
        }

}

fun IntruderAlert(context: Context) {

    val notification = NotificationCompat.Builder(
        context,
        "intruder_channel_id"
    )
        .setSmallIcon(R.drawable.intruder)
        .setContentTitle("Wykryto intruza!")
        .setContentText("Na kamerze zarejestrowano ruch.")
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .build()

    if (ActivityCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) != PackageManager.PERMISSION_GRANTED
    ) {
        // TODO: Consider calling
        //    ActivityCompat#requestPermissions
        // here to request the missing permissions, and then overriding
        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
        //                                          int[] grantResults)
        // to handle the case where the user grants the permission. See the documentation
        // for ActivityCompat#requestPermissions for more details.
    }

    //notificationManager.notify(1, notification)
    with(NotificationManagerCompat.from(context)) {
        notify(1, notification)
    }
}





