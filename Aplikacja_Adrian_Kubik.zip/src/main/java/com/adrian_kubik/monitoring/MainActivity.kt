package com.adrian_kubik.monitoring

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.adrian_kubik.monitoring.auth.helperviews.BlankLockScreen
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import com.adrian_kubik.monitoring.auth.views.HistoryScreen
import com.adrian_kubik.monitoring.auth.views.LoginScreen
import com.adrian_kubik.monitoring.auth.views.MainScreen
import com.adrian_kubik.monitoring.auth.views.SettingsScreen
import com.adrian_kubik.monitoring.auth.views.SignupScreen
import com.adrian_kubik.monitoring.auth.views.SuccessScreen
import com.adrian_kubik.monitoring.player.PlayerScreen
import com.adrian_kubik.monitoring.ui.theme.MonitoringTheme
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        @RequiresApi(Build.VERSION_CODES.TIRAMISU)
        if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.TIRAMISU) setPermission()

        setContent {
            val vm  = hiltViewModel<FbViewModel>()

            MonitoringTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AuthenticationApp(vm)
                }
            }
        }
    }

    @Composable
    fun AuthenticationApp(
        vm: FbViewModel
    ) {
        println("NavHost raz \n\n")

        val navController   = rememberNavController()
        BackHandler {
            navController.navigateUp()
        }
        NavHost(
            navController = navController,
            startDestination =if(vm.isSaveAuth) DestinationScreen.Blank.route else DestinationScreen.Main.route

        ) {
            composable(DestinationScreen.Main.route) {
                MainScreen(navController, vm)
            }
            composable(DestinationScreen.Signup.route) {
                SignupScreen(navController, vm)
            }
            composable(DestinationScreen.Login.route) {
                LoginScreen(navController, vm)
            }
            composable(DestinationScreen.Success.route) {
                SuccessScreen(navController, vm)
            }
            composable(DestinationScreen.Player.route) {
                PlayerScreen(navController, vm)
            }
            composable(DestinationScreen.History.route) {
                HistoryScreen(navController, vm)
            }
            composable(DestinationScreen.Settings.route) {
                SettingsScreen(navController, vm)
            }
            composable(DestinationScreen.Blank.route) {
                BlankLockScreen(navController, vm)
            }
        }
    }


    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    fun setPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            // Request the permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        }
    }
}

sealed class DestinationScreen(val route: String) {
    data object Main:       DestinationScreen("main")
    data object Signup:     DestinationScreen("signup")
    data object Login:      DestinationScreen("login")
    data object Success:    DestinationScreen("success")
    data object Player:     DestinationScreen("player")
    data object History:    DestinationScreen("history")
    data object Settings:   DestinationScreen("settings")
    data object Blank:      DestinationScreen("blank")
}





