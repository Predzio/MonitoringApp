package com.adrian_kubik.monitoring

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MonitoringApp: Application() {
}