package com.adrian_kubik.monitoring.autoauth

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("user_settings")
class UserSettingsRepository(context: Context) {
    private val tag             = "SETTINGS"
    private val dataStore       = context.dataStore

    companion object {
        val USER_NAME_KEY       = stringPreferencesKey("username")
        val PASSWORD_KEY        = stringPreferencesKey("password")
        val ISDETECT_KEY        = booleanPreferencesKey("isdetection")
        val DETECT_LEVEL_KEY    = booleanPreferencesKey("detectlevel")
    }

    suspend fun saveUserSettings(username: String, password: String) {
        dataStore.edit { preferences ->
            preferences[USER_NAME_KEY]  = username
            preferences[PASSWORD_KEY]   = password
        }
    }

    suspend fun saveSettings(isDetection: Boolean, detectionTextLevel: String) {
        val detectionLevel                  = detectionTextLevel == "Wysoki"
        dataStore.edit { preferences ->
            preferences[ISDETECT_KEY]       = isDetection
            preferences[DETECT_LEVEL_KEY]   = detectionLevel
        }
    }

    val userSettingsFlow: Flow<UserSettings> = context.dataStore.data.map { preferences ->
        val username    = preferences[USER_NAME_KEY]    ?: ""
        val password    = preferences[PASSWORD_KEY]     ?: ""
        val isdetection = preferences[ISDETECT_KEY]     ?: false
        val detectlevel = preferences[DETECT_LEVEL_KEY] ?: false
        UserSettings(
            username    = username,
            password    = password,
            isdetection = isdetection,
            detectlevel = detectlevel
        )
    }

    suspend fun getUsername() : String {
        return dataStore.data.first()[USER_NAME_KEY]    ?: ""
    }
    suspend fun getPassword() : String {
        return dataStore.data.first()[PASSWORD_KEY]     ?: ""
    }
    suspend fun getIsDetectionOn() : Boolean {
        return dataStore.data.first()[ISDETECT_KEY]     ?: false
    }
    suspend fun getDetectLevel() : Boolean {
        return dataStore.data.first()[DETECT_LEVEL_KEY] ?: false
    }
}

data class UserSettings(val username: String, val password: String, val isdetection: Boolean, val detectlevel: Boolean)