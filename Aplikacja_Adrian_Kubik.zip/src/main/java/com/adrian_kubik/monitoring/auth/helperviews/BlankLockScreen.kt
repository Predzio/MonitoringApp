package com.adrian_kubik.monitoring.auth.helperviews

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import com.adrian_kubik.monitoring.DestinationScreen
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

@Composable
fun BlankLockScreen(navController: NavHostController, vm: FbViewModel) {

    LockScreenOrientation(orientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
    CircularIndeterminateProgressBar()

    println("xd")
    LaunchedEffect(Unit) {
        withContext(Dispatchers.Main) {
            if(!vm.isSaveAuth) vm.initSettings()

            vm.login(vm.currentUsername, vm.currentPassword)
            delay(100)
            vm.getImages()
            vm.getCameraParam()
            runBlocking { vm.exPlayer.play(vm.getRTSP_URI()) }
            navController.navigate(DestinationScreen.Player.route) {
                popUpTo(DestinationScreen.Blank.route) { inclusive = true }
            }
        }
    }
}

@Composable
fun LockScreenOrientation(orientation: Int) {
    val context = LocalContext.current
    DisposableEffect(orientation) {
        val activity = context.findActivity() ?: return@DisposableEffect onDispose {}
        val originalOrientation = activity.requestedOrientation
        activity.requestedOrientation = orientation
        onDispose {
            // restore original orientation when view disappears
            // activity.requestedOrientation = originalOrientation
        }
    }
}

fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun CircularIndeterminateProgressBar() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator()// provided by compose library
    }
}