package com.adrian_kubik.monitoring.auth.views

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.adrian_kubik.monitoring.DestinationScreen
import com.adrian_kubik.monitoring.R
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel

@Composable
fun SuccessScreen(
    navController: NavController,
    vm: FbViewModel
) {
    val empty                   by remember { mutableStateOf("") }
    var ip                      by remember { mutableStateOf("") }
    var login                   by remember { mutableStateOf("") }
    var password                by remember { mutableStateOf("") }
    var passwordVisibility      by remember { mutableStateOf(false) }
    var path                    by remember { mutableStateOf("") }
    var erroeL                  by remember { mutableStateOf(false) }
    var erroeIP                 by remember { mutableStateOf(false) }
    var erroeP                  by remember { mutableStateOf(false) }
    var erroePath               by remember { mutableStateOf(false) }

    Image(
        painter = painterResource(id = R.drawable.black_gradient),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = Modifier.fillMaxSize(),
    )
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 150.dp)
            .verticalScroll(
                rememberScrollState()
            )
    ) {
        Text(
            text = "Dodaj kamerę",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 40.sp
        )
        Spacer(modifier = Modifier.height(50.dp))
        if(erroeIP){
            Text(text = "Wprowadź ip",
                color = Color.Red,
                modifier = Modifier.padding(end = 100.dp)
            )
        }
        TextField(
            value = ip,
            onValueChange = {
                ip = it
            },
            label = {
                Text(text = "Adres IP")
            },
            leadingIcon = {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_person_24),
                    contentDescription = null
                )
            },
            trailingIcon = {
                if(ip.isNotEmpty()){
                    Icon(painter = painterResource(
                        id = R.drawable.baseline_close_24),
                        contentDescription = null,
                        Modifier.clickable { ip = empty }
                    )
                }
            },
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Next
            ),
            singleLine = true,
            textStyle = TextStyle(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            ),
            shape = RoundedCornerShape(50.dp),
            modifier = Modifier
                .width(300.dp)
                .height(60.dp),
        )
        Spacer(modifier = Modifier.height(30.dp))
        if(erroeL){
            Text(text = "Wprowadź login",
                color = Color.Red,
                modifier = Modifier.padding(end = 100.dp)
            )
        }
        TextField(
            value = login,
            onValueChange = {
                login = it
            },
            label = {
                Text(text = "login")
            },
            leadingIcon = {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_person_24),
                    contentDescription = null
                )
            },
            trailingIcon = {
                if(login.isNotEmpty()){
                    Icon(painter = painterResource(
                        id = R.drawable.baseline_close_24),
                        contentDescription = null,
                        Modifier.clickable { login = empty }
                    )
                }
            },
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Next
            ),
            singleLine = true,
            textStyle = TextStyle(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            ),
            shape = RoundedCornerShape(50.dp),
            modifier = Modifier
                .width(300.dp)
                .height(60.dp),
        )
        Spacer(modifier = Modifier.height(30.dp))
        if(erroeP){
            Text(
                text = "Wprowadź hasło",
                color = Color.Red,
                modifier = Modifier.padding(end = 100.dp)
            )
        }
        TextField(
            value = password,
            onValueChange = {
                password    = it
            },
            label = {
                Text(text = "Hasło")
            },
            leadingIcon = {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_lock_24),
                    contentDescription = null
                )
            },
            trailingIcon = {
                if(password.isNotEmpty()){
                    val visibilityIcon = if(passwordVisibility){
                        painterResource(id = R.drawable.baseline_visibility_24)
                    }
                    else{
                        painterResource(id = R.drawable.baseline_visibility_off_24)
                    }
                    Icon(painter = visibilityIcon,
                        contentDescription = if(passwordVisibility) "Ukryj hasło"
                        else "Pokaż hasło",
                        Modifier.clickable {
                            passwordVisibility = !passwordVisibility
                        }
                    )
                }
            },
            visualTransformation = (
                    if(passwordVisibility) VisualTransformation.None
                    else PasswordVisualTransformation()
                    ),
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Done,
                keyboardType = KeyboardType.Password
            ),
            singleLine = true,
            textStyle = TextStyle(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            ),
            shape = RoundedCornerShape(50.dp),
            modifier = Modifier
                .width(300.dp)
                .height(60.dp),
        )
        Spacer(modifier = Modifier.height(30.dp))
        if(erroePath){
            Text(text = "Wprowadź ścieżkę wideo",
                color = Color.Red,
                modifier = Modifier.padding(end = 100.dp)
            )
        }
        TextField(
            value = path,
            onValueChange = {
                path = it
            },
            label = {
                Text(text = "sciezka")
            },
            leadingIcon = {
                Icon(
                    painter = painterResource(id = R.drawable.baseline_video_file_24),
                    contentDescription = null
                )
            },
            trailingIcon = {
                if(path.isNotEmpty()){
                    Icon(painter = painterResource(
                        id = R.drawable.baseline_close_24),
                        contentDescription = null,
                        Modifier.clickable { path = empty }
                    )
                }
            },
            keyboardOptions = KeyboardOptions(
                imeAction = ImeAction.Done
            ),
            singleLine = true,
            textStyle = TextStyle(
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            ),
            shape = RoundedCornerShape(50.dp),
            modifier = Modifier
                .width(300.dp)
                .height(60.dp),
        )
        Spacer(modifier = Modifier.height(50.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50.dp))
                .background(color = Color.White)
        ){
            Button(
                onClick = {
                    if(ip.isNotEmpty()){
                        erroeIP = false
                        if(password.isNotEmpty()){
                            erroeP = false
                            if(path.isNotEmpty()){
                                erroePath = false
                                vm.insertCameraParam(ip, login, password, path)
                                navController.navigate(DestinationScreen.Main.route)
                            }
                            else{
                                erroePath = true
                            }
                        }
                        else{
                            erroeP = true
                        }
                    }
                    else{
                        erroeIP = true
                    }
                },
                colors = ButtonDefaults.buttonColors(Color.Transparent),
                modifier = Modifier.width(200.dp)
            ) {
                Text(
                    text = "Dodaj kamerę",
                    color = Color.Black,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

}