package com.adrian_kubik.monitoring.auth.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.adrian_kubik.monitoring.Event
import com.adrian_kubik.monitoring.ImageBMP
import com.adrian_kubik.monitoring.auth.Camera
import com.adrian_kubik.monitoring.auth.views.HistoryItem
import com.adrian_kubik.monitoring.autoauth.UserSettingsRepository
import com.adrian_kubik.odtwarzaczrtsp.ExoPlayerWrapper
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import org.opencv.android.OpenCVLoader
import javax.inject.Inject


@HiltViewModel
class FbViewModel @Inject constructor(
    application: Application,
    val auth : FirebaseAuth
): ViewModel() {
    var isSaveAuth                      = false
    var currentUsername                 = ""
    var currentPassword                 = ""
    val isDetectionOn                   = mutableStateOf(false)
    val isDetectionLevel                = mutableStateOf(false)
    val popupNotification               = mutableStateOf<Event<String>?>(null)
    private val db                              = Firebase.firestore
    private var cam                     = Camera("x", "x", "x")
    var historyList                     = mutableStateListOf<HistoryItem>()
    var userSettingsRepository          = UserSettingsRepository(application.baseContext)
    var exPlayer: ExoPlayerWrapper      = ExoPlayerWrapper(application.baseContext)

    init{
        if (!OpenCVLoader.initDebug()) {
            Log.d("FbViewModel", "Init OpenCVLoader is failed!")
        }
        runBlocking {
            initSettings()
            delay(200)
        }
    }
    fun onSignup(
        email: String,
        pass: String
    ) {
        auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener {
                if(it.isSuccessful) {
                    handleException(it.exception, "Rejestracja zakończona sukcesem")
                }
                else {
                    handleException(it.exception, "Rejestracja zakończona niepowodzeniem")
                }
            }
    }

    fun login(
        email: String,
        pass: String
    ){
        auth.signInWithEmailAndPassword(email.trim(), pass.trim())
            .addOnCompleteListener{
                if(it.isSuccessful){
                    handleException(it.exception, "\n\nLogowanie zakończone sukcesem")
                }
                else {
                    handleException(it.exception, "\n\nNiepoprawne dane logowania")
                }
            }
    }

    suspend fun getCameraParam() :Boolean {
        val uid = auth.currentUser?.uid
        var result = false
        if(uid != null) {
            println("Nie jestem null")
            val docCamera = db.collection("kamery").document(uid)
            docCamera.get()
                .addOnSuccessListener {
                    if (it != null) {
                        println("DocumentSnapshot data: ${it.data}")
                        val ip = it.data?.getValue("ip")
                        val login = it.data?.getValue("login")
                        val pwd = it.data?.getValue("pwd")
                        val path = it.data?.getValue("path")
                        cam =
                            Camera(ip.toString(), login.toString(), pwd.toString(), path.toString())

                        result = true
                    } else {
                        println("No such document")
                    }

                }
                .addOnFailureListener {
                    println("Get failed with $it")
                }.await()
        }else {
            println("Null")
        }
        delay(30)
        return result
    }

    fun insertCameraParam(
        ip:     String,
        login:  String,
        pwd:    String,
        path:   String
    ) {
        val uid = auth.currentUser?.uid

        if (uid != null) {
            val camera = Camera(ip = ip, login = login, pwd = pwd, path = path)
            val dbCamera = db.collection("kamery")

            dbCamera.document(uid)
                .set(camera.getHashMapOf())
                .addOnSuccessListener {
                    println("DocumentSnapshot added")

                }
                .addOnFailureListener {
                    println("Error adding document \n $it")
                }
        }
    }

    fun insertImage(
        img:    ByteArray
    ) {
        val uid = auth.currentUser?.uid
        val imageData: ByteArray = img

        // Konwertuj dane binarne na base64
        val base64Image = Base64.encodeToString(imageData, Base64.DEFAULT)

        // Pobierz obecny czas jako Timestamp
        val timestamp = Timestamp.now()

        /* Utwórz obiekt do zapisania w Firestore
        val imageDocument = hashMapOf(
            "imageData" to base64Image,
            "timestamp" to timestamp
        )*/

        println("Dodaje zdjęcie")
        if (uid != null) {
            println("Nie jest null")
            val imgBMP = ImageBMP(imgData = base64Image, timestamp = timestamp)
            val dbCamera = db.collection("bitmap_$uid")
            println("")
            dbCamera.document()
                .set(imgBMP.getHashMapOf())
                .addOnSuccessListener {
                    println("DocumentSnapshot added")
                }
                .addOnFailureListener {
                    println("Error adding document \n $it")
                }
        }
    }

    suspend fun getImages(): Boolean {
        val uid = auth.currentUser?.uid
        var result = false

        if (uid != null) {

            val imagesCollection = db.collection("bitmap_$uid") //"bitmap_$uid"
            imagesCollection.get()
                .addOnSuccessListener { querySnapshot ->
                    // Wyczyść listę
                    result = true
                    historyList.clear()
                    println("Pobieram obrazy")
                    for (document in querySnapshot) {
                        // Pobierz dane z dokumentu
                        val base64Image: String = document.getString("img") ?: ""
                        val timestamp: Timestamp = document.getTimestamp("date") ?: Timestamp.now()

                        // Dekoduj dane base64 na ByteArray
                        val imageData: ByteArray = Base64.decode(base64Image, Base64.DEFAULT)

                        // Konwersja byte array na Bitmap
                        val bitmap: Bitmap? = BitmapFactory.decodeByteArray(imageData, 0, imageData.size)

                        if (bitmap != null) {

                            val item = HistoryItem(bitmap = bitmap, date = timestamp)
                            println("Dodałem obraz")
                            historyList.add(item)
                        } else {

                        }
                    }

                }
                .addOnFailureListener { e ->
                    println("Get failed with $e")
                }.await()

        }
        delay(30)
        return result
    }

    fun deleteImage(item: HistoryItem) {
        val uid = auth.currentUser?.uid

        if (uid != null) {
            val imagesCollection = db.collection("bitmap_$uid").whereEqualTo("date", item.date)
            imagesCollection.get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    for (document in task.result) {
                        document.reference.delete()
                            .addOnSuccessListener{
                                    println("Document successfully deleted!")
                            }
                            .addOnFailureListener {

                               println("Error deleting document")
                             }
                    }
                } else {
                    println("Error getting documents: " + task.exception) //Don't ignore potential errors!
                }
            }

        }
    }

    fun getRTSP_URI(): String {
        var result = "rtsp://"
        result += cam.getLogin() +":"
        result += cam.getPassword() +"@"
        result += cam.getIP()
        result += "/${cam.getPath()}"

        return result
    }

    fun handleException(exception: Exception? = null, customMessage: String = "") {
        exception?.printStackTrace()
        val errorMsg = exception?.localizedMessage ?: ""
        val message = if(customMessage.isEmpty()) errorMsg else "$customMessage: $errorMsg"
        popupNotification.value = Event(message)
    }

    suspend fun initSettings() {
        currentUsername         = userSettingsRepository.getUsername()
        currentPassword         = userSettingsRepository.getPassword()
        isDetectionOn.value     = userSettingsRepository.getIsDetectionOn()
        isDetectionLevel.value  = userSettingsRepository.getDetectLevel()
        isSaveAuth = currentUsername.isNotEmpty() && currentPassword.isNotEmpty()
    }
}

