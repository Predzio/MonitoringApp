package com.adrian_kubik.monitoring.auth.views

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import androidx.navigation.NavController
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun SettingsScreen(
    navController: NavController,
    vm: FbViewModel
) {
    val tag = "SETTING_COMPOSE"
    var isEnabledButton by remember { mutableStateOf(true) }
    var expanded by remember { mutableStateOf(false) }
    val mCities = listOf("Niski", "Wysoki")
    var mSelectedText by remember { mutableStateOf("Niski") }
    var mTextFieldSize by remember { mutableStateOf(Size.Zero)}
    val icon = if (expanded)
        Icons.Filled.KeyboardArrowUp
    else
        Icons.Filled.KeyboardArrowDown

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Toggle switch for enabling/disabling detection
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Uruchom detekcje", modifier = Modifier.weight(1f))
            Switch(
                checked = vm.isDetectionOn.value,
                onCheckedChange = { vm.isDetectionOn.value = it },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedTextField(
                value = mSelectedText,
                onValueChange = { mSelectedText = it },
                modifier = Modifier
                    .width(200.dp)
                    .onGloballyPositioned { coordinates ->
                        mTextFieldSize = coordinates.size.toSize()
                    },
                label = {Text("Wrażliwość detekcji", modifier = Modifier.weight(1f))},
                trailingIcon = {
                    Icon(icon,"contentDescription",
                        Modifier.clickable { expanded = !expanded })
                }
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier
                    .width(with(LocalDensity.current){mTextFieldSize.width.toDp()})
            ) {
                mCities.forEach {
                    DropdownMenuItem(
                        onClick = {
                        mSelectedText = it
                        expanded = false
                        },
                        text = { Text(text = it) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(100.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = {
                    isEnabledButton = false
                    runBlocking { saveSettings(vm, mSelectedText) }
                    navController.navigateUp()
                    isEnabledButton = true
                },
                enabled = isEnabledButton,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Text("Zapisz")
            }
        }
    }
}

suspend fun saveSettings(
    vm: FbViewModel,
    detectionTextLevel: String
) = coroutineScope {
        withContext(Dispatchers.IO) {
            vm.isDetectionLevel.value = (detectionTextLevel == "Wysoki")
            vm.userSettingsRepository?.saveSettings(vm.isDetectionOn.value, detectionTextLevel)
            delay(20)
        }

}

