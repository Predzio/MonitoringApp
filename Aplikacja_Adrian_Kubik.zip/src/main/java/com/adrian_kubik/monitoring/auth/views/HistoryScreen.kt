package com.adrian_kubik.monitoring.auth.views

import android.annotation.SuppressLint
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat


data class HistoryItem(val bitmap: Bitmap, val date: Timestamp)

fun getDateAndTime(historyItem: HistoryItem): String {
    return SimpleDateFormat("dd.MM.yyyy HH:mm:ss", java.util.Locale.US)
        .format(historyItem.date.toDate())
}

@Composable
fun HistoryItemCard(
    historyItem: HistoryItem,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Image(
                bitmap = historyItem.bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .width(640.dp)
                    .height(360.dp)
                    .clip(MaterialTheme.shapes.medium),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text  = getDateAndTime(historyItem),
                style = MaterialTheme.typography.bodyLarge
            )
            Button(
                onClick = onDeleteClick,
                modifier = Modifier.width(200.dp)
            ) {
                Text(
                    text = "Usuń",
                    color = Color.Black,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    navController: NavController,
    vm: FbViewModel,

) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Historia") },
                modifier = Modifier.background( MaterialTheme.colorScheme.primary)
            )
        }
    ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                state = rememberLazyListState()
            ) {
                    items(vm.historyList) { historyItem ->
                        HistoryItemCard(historyItem, onDeleteClick = {
                            println("Usuwam zdjęcie: ${historyItem.date} ${historyItem.bitmap}")

                            vm.historyList.remove(historyItem)
                            vm.deleteImage(historyItem)
                        })
                    }
            }
    }
}

