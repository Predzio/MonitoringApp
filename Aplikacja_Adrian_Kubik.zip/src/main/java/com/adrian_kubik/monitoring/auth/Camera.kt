package com.adrian_kubik.monitoring.auth

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class Camera(
    private val ip: String? = null,
    private val login: String? = null,
    private val pwd: String? = null,
    private val path: String? = null
) {
    fun getHashMapOf(): HashMap<String, String?> {
        return hashMapOf(
            "ip" to ip,
            "login" to login,
            "pwd" to pwd,
            "path" to path
        )
    }

    fun getIP(): String? {
        return ip
    }

    fun getLogin(): String? {
        return login
    }

    fun getPassword(): String? {
        return pwd
    }

    fun getPath(): String? {
        return path
    }
}
