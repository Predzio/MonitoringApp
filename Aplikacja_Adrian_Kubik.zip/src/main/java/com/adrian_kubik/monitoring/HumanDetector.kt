package com.adrian_kubik.monitoring

class HumanDetector {
    /*
        lateinit var poseDetector: PoseDetector
        val context = LocalContext.current
    val options = PoseDetectorOptions.Builder()
        .setDetectorMode(PoseDetectorOptions.STREAM_MODE)
        .build()
        poseDetector = PoseDetection.getClient(options)



        var poseLandmarks by remember { mutableStateOf<List<PoseLandmark>>(emptyList()) }


        CameraView(context).apply {
            //modifier = Modifier.fillMaxSize()

            addFrameProcessor(object : FrameProcessor {
                override fun process(frame: Frame) {
                    val mediaImage = frame.getData<Image>()
                    println("Hej dodaje ramke")
                    if (mediaImage != null) {
                        val inputImage = InputImage.fromMediaImage(
                            mediaImage,
                            frame.rotationToUser
                        )

                        poseDetector.process(inputImage)
                            .addOnSuccessListener { detectedPoses ->
                                if (detectedPoses != null) {
                                    poseLandmarks = detectedPoses.allPoseLandmarks
                                    println("Wykryto")
                                }
                            }
                    }
                }
            })
        }

        // Tu możesz użyć poseLandmarks do czegoś związanego z pozycją postury
        // Na przykład, narysuj punkty na ekranie
        for (landmark in poseLandmarks) {
            // Twój kod do obsługi punktów postury
        }*/

}