package com.adrian_kubik.monitoring.DetectAlgorithm

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc

class DifferencePixel() {
    private var previousFrame: Mat
    private var currentFrame: Mat

    init {
        previousFrame   = Mat()
        currentFrame    = Mat()
    }

    constructor(b: Bitmap) : this() {
        previousFrame   = Mat(b.width, b.height, CvType.CV_8UC1)
        Utils.bitmapToMat(b, previousFrame)
        Imgproc.cvtColor(previousFrame, previousFrame, Imgproc.COLOR_BGR2GRAY)
    }

    fun activeDetection(
        b: Bitmap
    ) : Boolean {
        val diffGray        = Mat(b.width, b.height, CvType.CV_8UC1)
        val secondGray      = Mat(b.width, b.height, CvType.CV_8UC1)

        //Konwertuj bitmape do macierzy
        currentFrame.release()
        currentFrame = Mat(b.width, b.height, CvType.CV_8UC1)
        Utils.bitmapToMat(b, currentFrame)

        //Nadaj odcienie szarości
        Imgproc.cvtColor(currentFrame, secondGray, Imgproc.COLOR_BGR2GRAY)

        Core.absdiff(previousFrame, secondGray, diffGray)

        //Imgproc.cvtColor(diff, diffGray, Imgproc.COLOR_BGR2GRAY)

        // Prosta detekcja ruchu: jeśli istnieją piksele o wartości różnej od zera, uznajemy to za ruch
        val result_countNonZero = Core.countNonZero(diffGray)
        val motionDetected =  result_countNonZero > 3_000_000

        if(motionDetected) {
            println("Wartość: $result_countNonZero")
            println("Wykryto ruch")

        }
        else {
            println("Nie wykryto")
        }
        previousFrame.release()
        previousFrame = secondGray.clone()

        diffGray.release()
        secondGray.release()

        return motionDetected
    }



}