package com.adrian_kubik.monitoring.DetectAlgorithm

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.MatOfRect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import org.opencv.objdetect.HOGDescriptor

class HogMotionDetector {
    private var hogDescriptor: HOGDescriptor
    private var currentFrame: Mat

    init {
        currentFrame = Mat()
        hogDescriptor = HOGDescriptor()
        hogDescriptor.setSVMDetector(HOGDescriptor.getDefaultPeopleDetector())
    }

    fun detectMotion(b: Bitmap): Boolean {
        val frameGray = Mat(b.width, b.height, CvType.CV_8UC1)

        currentFrame.release()
        currentFrame = Mat(b.width, b.height, CvType.CV_8UC1)
        Utils.bitmapToMat(b, currentFrame)

        Imgproc.cvtColor(currentFrame, frameGray, Imgproc.COLOR_BGR2GRAY)
        println("Detekcja")
        val foundPersons    = MatOfRect()
        val weightsPersons  = MatOfDouble()
        hogDescriptor.detectMultiScale(
            frameGray,
            foundPersons,
            weightsPersons,
            0.0,
            Size(16.0, 16.0),
            Size(0.0, 0.0),
            1.01,
            2.0,
            false
        )

        val arrayPerson = foundPersons.toArray()
        val numPersons = arrayPerson.size

        if(numPersons > 0) println("Liczba wykrytych osób: $numPersons")
        for(i in 0..<numPersons) {
            print("$i person size " +arrayPerson[i].size().toString())
            print(" weight " +weightsPersons.size() +"\n")
        }

        frameGray.release()
        return numPersons > 0
    }
}