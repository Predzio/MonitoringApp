package com.adrian_kubik.odtwarzaczrtsp

import android.content.Context
import android.graphics.Bitmap
import android.view.TextureView
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.rtsp.RtspMediaSource
import androidx.media3.exoplayer.source.MediaSource
import java.io.ByteArrayOutputStream

@UnstableApi
class ExoPlayerWrapper(context: Context) {
    private val exPlayer = ExoPlayer.Builder(context).build()
    private val textureView = TextureView(context)

    fun play(uri: String) {
        setOptionsExoPlayer(uri)
        //exPlayer.play()
        exPlayer.setVideoTextureView(textureView)
    }

    @OptIn(UnstableApi::class)
    private fun setOptionsExoPlayer(
        uri: String
    ) {
        val mediaSource: MediaSource =
            RtspMediaSource.Factory()
                .createMediaSource(MediaItem.fromUri(uri))

        exPlayer.setMediaSource(mediaSource)
        exPlayer.prepare()
        exPlayer.playWhenReady = true
    }

    private fun setOptionsTextureView() {

    }

    fun getExoPlayer(): ExoPlayer {
        return exPlayer
    }

    fun getBitmap(): Bitmap {
        return textureView.bitmap!!
    }

    fun getImageData(): ByteArray {
        val bmp = getBitmap()
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos)

        return baos.toByteArray()
    }

    fun getImageDataFrom(bmp: Bitmap): ByteArray {
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos)

        return baos.toByteArray()
    }

    fun getSurfacePlayer(): TextureView {
        return textureView
    }

    fun releaseAll() {
        exPlayer.stop()
        exPlayer.release()
    }

    fun getVideoFormat() {

    }
}