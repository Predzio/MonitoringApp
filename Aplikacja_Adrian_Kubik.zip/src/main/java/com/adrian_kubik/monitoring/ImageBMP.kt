package com.adrian_kubik.monitoring

import com.google.firebase.Timestamp
import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class ImageBMP(
    private val imgData:    String,
    private val timestamp: Timestamp
) {
    fun getHashMapOf(): HashMap<String, Any> {
        return hashMapOf(
            "img"   to imgData,
            "date"  to timestamp
        )
    }

    fun getImageBMP(): String {
        return imgData
    }

    fun getDate(): Timestamp {
        return timestamp
    }
}
