package com.adrian_kubik.monitoring

import com.adrian_kubik.monitoring.auth.viewmodel.FbViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.runBlockingTest
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.mockito.InjectMocks
import org.mockito.Mock
import org.mockito.Mockito.doReturn
import org.mockito.junit.MockitoJUnit
import org.mockito.junit.MockitoRule

@ExperimentalCoroutinesApi
class LoginTest {
    //val viewModel = FbViewModel(FirebaseAuth.getInstance())

    @get:Rule
    val mockitoRule: MockitoRule = MockitoJUnit.rule()

    @get:Rule
    val coroutinesTestRule = CoroutinesTestRule()

    // Wstrzyknięcie mocków za pomocą Mockito
    @Mock
    lateinit var auth: FirebaseAuth

    @InjectMocks
    lateinit var viewModel: FbViewModel

    @Test
    fun `login should update signedIn when successful`() = coroutinesTestRule.testDispatcher.runBlockingTest {
        // Przygotowanie danych testowych
        val email = "adrian2679@poczta.onet.pl"
        val password = "Picipolo09"

        // Konfiguracja zachowania mocka
        doReturn("").`when`(auth).signInWithEmailAndPassword(email, password)

        // Wywołanie funkcji testowanej
        viewModel.login(email, password)

        // Sprawdzenie rezultatów
        assertTrue(viewModel.signedIn.value)
        // Sprawdzenie, czy inna wartość się nie zmieniła, np. inProgress
        assertFalse(viewModel.inProgress.value)
    }

}