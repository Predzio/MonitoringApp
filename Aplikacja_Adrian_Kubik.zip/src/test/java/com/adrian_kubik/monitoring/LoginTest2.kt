package com.adrian_kubik.monitoring
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

//@ExperimentalCoroutinesApi

@RunWith(JUnit4::class)
class LoginTest2{

    //private val testDispatcher = TestCoroutineDispatcher()
    private val register = InstrumentationRegistry.getInstrumentation()

    @Before
    fun setup() {
        // Inicjalizacja FirebaseApp (możesz dostosować do swojego kontekstu)
        //ApplicationProvider.getApplicationContext()
        //val app = FirebaseApp.initializeApp(register.targetContext)
        // Inicjalizacja CoroutineDispatcher
        //Dispatchers.setMain(testDispatcher)
    }

    @After
    fun cleanup() {
        // Reset CoroutineDispatcher po zakończeniu testów
        //Dispatchers.resetMain()
        //testDispatcher.cleanupTestCoroutines()
    }

    @Test
    fun testLogin() {
        // Tworzenie instancji ViewModel
        //val viewModel = FbViewModel(FirebaseAuth.getInstance())

        // Tworzenie danych testowych
        val email = "test@example.com"
        val password = "testPassword"

        // Uruchomienie testu w coroutine
        //testDispatcher.runBlockingTest {
            // Wywołanie funkcji logowania
            //viewModel.login(email, password)
            assert(true)
            // Asercje
            //assert(viewModel.inProgress.value, true)  // Oczekujemy, że inProgress będzie ustawione na true

            // Tutaj można dodać więcej asercji w zależności od oczekiwanego zachowania
       // }
    }
}


